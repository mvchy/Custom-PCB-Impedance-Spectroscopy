/**
 * @file   nxp-z-measurement-v2.c
 * @brief  NXP k64f Board Code
 */
#include <math.h>
#include <stdio.h>
#include "board.h"
#include "peripherals.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "MK64F12.h"
#include "fsl_debug_console.h"
#include "fsl_port.h"
#include "fsl_gpio.h"
#include "fsl_common.h"
#include "fsl_uart.h"

#include "fsl_dac.h"
#include "fsl_pit.h"
#include "fsl_dmamux.h"
#include "fsl_edma.h"
#include "fsl_adc16.h"
#include "arm_math.h"
#include "arm_const_structs.h"


#define BOTTON_MEASURE_GPIO			BOARD_A1_SW_GPIO
#define BOTTON_MEASURE_PORT			BOARD_A1_SW_PORT
#define BOTTON_MEASURE_GPIO_PIN		BOARD_A1_SW_GPIO_PIN
#define BOTTON_MEASURE_IRQ			BOARD_A1_SW_IRQ
#define BOTTON_MEASURE_IRQ_HANDLER	BOARD_A1_SW_IRQ_HANDLER
#define BOTTON_MEASURE_NAME			BOARD_A1_SW_NAME


#define CONTROL_MEASURE_GPIO		GPIOC
#define CONTROL_MEASURE_PORT		PORTC
#define CONTROL_MEASURE_GPIO_PIN	16U


volatile bool flagButtonMeasurePressed = false;


/* PIT */  // used to be 0
#define PIT_HANDLER PIT1_IRQHandler
#define PIT_IRQ_ID PIT1_IRQn
#define PIT_SOURCE_CLOCK CLOCK_GetFreq(kCLOCK_BusClk)
#define PIT_CHANNEL kPIT_Chnl_0


#define signalSize 16384 // change from 4096 to 8192

/* UART*/
#define UART_IRQn       UART1_RX_TX_IRQn
#define UART_IRQHandler UART1_RX_TX_IRQHandler
#define UART_CLK_FREQ_SOURCE CLOCK_GetFreq(UART1_CLK_SRC)

/* ADC */
#define ADC16_BASEADDR ADC0
#define ADC16_BASEADDR_A1 ADC1
#define ADC16_CHANNEL_GROUP 0U
#define ADC16_USER_CHANNEL 1U /* 12U, PTB2, ADC0_SE12 */
#define ADC_SAMPLE_SIZE signalSize
#define ADC_SAMPLE_FREQ 786432
#define DAC_SAMPLE_FREQ 786432



uint16_t buffer[ADC_SAMPLE_SIZE];
uint16_t buffer_A1[ADC_SAMPLE_SIZE];
uint8_t header_check=0;

volatile int ADC_FIRST_PERIOD_DELAY = ADC_SAMPLE_SIZE;
volatile uint16_t ADC_SAMPLE_COUNTER = 0;


/* Initialization */
void led_init();
void led_white_on();
void led_red_on();
void led_blue_on();
void led_white_off();

void BOTTON_MEASURE_init(void);
void BOTTON_MEASURE_IRQ_HANDLER(void);

void PIT_HANDLER(void);
void DAC_ADC_init();
void UART_init();
void PGA_gpio_init();
void PGA0_unitGain();
void PGA1_unitGain();
void PGA0_02xGain();
void PGA1_02xGain();
void PGA0_05xGain();
void PGA1_05xGain();
void PGA0_10xGain();
void PGA1_10xGain();
void PGA0_20xGain();
void PGA1_20xGain();
void PGA0_50xGain();
void PGA1_50xGain();
void PGA0_100xGain();
void PGA1_100xGain();


/* Buffer array and UART sending package/ pattern */
void uart_send_bytes(uint8_t *p, uint16_t size);
void send_result();
#define RESULT_BUFFER_SIZE signalSize
#define RESULT_PATTERN_CODE_lowfreq_u16     1
#define RESULT_PATTERN_CODE_highfreq_u16    2
uint32_t header_sample_number = ADC_SAMPLE_SIZE;
uint16_t result_buffer[RESULT_BUFFER_SIZE];
uint16_t result_buffer_A1[RESULT_BUFFER_SIZE];


#define SINEWAVE_SAMPLE_CNT signalSize
#define SOURCE_CNT SINEWAVE_SAMPLE_CNT

uint32_t header_pattern_code = RESULT_PATTERN_CODE_highfreq_u16;
uint32_t header_adc_sample = ADC_SAMPLE_FREQ;

uint32_t PGA0_gain;
uint32_t PGA1_gain;

// --- Define Signal Array's Parameters ---
#define SIGNAL_ARRAY_SIZE signalSize
#define SIGNAL_LOWER_LIMIT 0
#define SIGNAL_UPPER_LIMIT 2482 // output voltage = 2v (for NXP DAC 12 bit)

uint16_t globalSignalArray[SIGNAL_ARRAY_SIZE];

#define SOURCE_ADDRESS &globalSignalArray[0]


volatile bool flagMeasureRequested = false; // Set when USER requesting to measure.
volatile bool flagMeasuring        = false; // Set when ADC buffer contain the active measuring data.
volatile bool flagSendingRequested = false; // Set when DATA in buffer is ready to send.

/* Debugging pins */
void initMarker();
void startMeasureMarker();
void stopMeasureMarker();
void togglePITMarker();

void copyToSendingBuffer();

/* function for generate sin wave */
void generateSignalArray(float32_t target_frequency);
void getNormalizedSignalArray(float32_t *pSourceSignalArray, uint16_t *pNormSignalArray, int length, uint16_t lowerLimit, uint16_t upperLimit);
void addSineWave(float32_t *pSignalArray, int length, float32_t frequency, float32_t amplitude);
void fillSignalArray(float32_t *pSignalArray, int length, float32_t value);



int main(void)
{
  	/* Init board hardware. */
    BOARD_InitBootPins();
    BOARD_InitBootClocks();
    BOARD_InitBootPeripherals();

  	/* Init FSL debug console.aka, UAR T PRINTF */
    BOARD_InitDebugConsole();

    BOTTON_MEASURE_init();

	led_init();
	led_white_off();
	initMarker();

	DAC_ADC_init();
	UART_init();
	PGA_gpio_init();

	/*set PGA*/
	PGA0_unitGain();
	PGA1_unitGain();

	/*set frequency*/
	float32_t frequency_list[]= {99984,90000,80016,70032,60000,50016,40032,30000,20016,10032,9984,9024,8016,7008,6000,5040,4032,3024,2016,1008,912,816,768,672,528,480,384,192,96,48};
	int frequency_sweep = sizeof(frequency_list)/sizeof(float32_t);
	uint32_t frequency_header[]={99984,90000,80016,70032,60000,50016,40032,30000,20016,10032,9984,9024,8016,7008,6000,5040,4032,3024,2016,1008,912,816,768,672,528,480,384,192,96,48};



    while(true)
    {
    	if (flagMeasureRequested) {

			startMeasureMarker();
			led_blue_on();

	        for (int j=0; j< 5000000; j++){
	        	volatile int k = 0;
	        	k++;
	        }

   		    for (int i=0; i< frequency_sweep; i++){

   		    		/*set PGA for each frequency range >> PGA0 for DUT and PGA1 for Rknown resistor(1k ohm)*/
					if (frequency_list[i]>=10000)
					{
						PGA0_10xGain();
						PGA1_unitGain();

					} else if ((frequency_list[i]<10000)&&(frequency_list[i]>=1000)) {
						PGA0_10xGain();
						PGA1_unitGain();

					}else {
						PGA0_unitGain();
						PGA1_unitGain();
					}
					/*generate sine wave for each frequency to global array*/
    		        generateSignalArray(frequency_list[i]);


    		        for (int j=0; j< 2000000; j++){
    		        	volatile int k = 0;
    		        	k++;
    		        }

    		        /*copy ADC data to buffer array*/

    		        header_pattern_code = frequency_header[i];
    	    		copyToSendingBuffer();
    		        for (int j=0; j< 5000000; j++){
    		        	volatile int k = 0;
    		        	k++;
    		        }
    	    		led_white_on();
    	    		send_result();
    	    		led_white_off();
    		        for (int j=0; j< 5000000; j++){
    		        	volatile int k = 0;
    		        	k++;
    		        }
    		}

			stopMeasureMarker();
			flagMeasureRequested = false;
			memset(globalSignalArray,0,signalSize*sizeof(uint16_t));
    	}
    }

    return 0;
}



// PIT: Attached with ADC, assumed that the ADC's PIT is following the DAC's PIT. with the same frequency.
void PIT_HANDLER(void){
    /* Clear interrupt flag.*/
    PIT_ClearStatusFlags(PIT, kPIT_Chnl_1, kPIT_TimerFlag);
    togglePITMarker();

    ADC0->SC1[ADC16_CHANNEL_GROUP]= ADC16_USER_CHANNEL; // DMA request for ADC // ADC0_DM1 : ADC0_DP1
    ADC1->SC1[ADC16_CHANNEL_GROUP]= ADC16_USER_CHANNEL; // DMA request for ADC // ADC0_DM1 : ADC0_DP1

    if (ADC_SAMPLE_COUNTER == 0){
		// Set some indicator
    }
    ADC_SAMPLE_COUNTER++;

    if (ADC_SAMPLE_COUNTER >= ADC_SAMPLE_SIZE){
    	ADC_SAMPLE_COUNTER = 0;
    	DMA0->SERQ = DMA_SERQ_SERQ(1); // enable DMA channel 1
    	DMA0->SERQ = DMA_SERQ_SERQ(2);
    	DMA0->SERQ = DMA_SERQ_SERQ(0);
    }
}


void UART_init(void){

		UART_EnableInterrupts(UART0, kUART_RxDataRegFullInterruptEnable );
		EnableIRQ(BOARD_UART_IRQ);
}


void BOARD_UART_IRQ_HANDLER(void){

    if ((kUART_RxDataRegFullFlag ) & UART_GetStatusFlags(UART0))
    {
    	header_check = UART_ReadByte(UART0);
    			if (header_check == 37)
    			{
    					flagMeasureRequested = true;
    					header_check = 0;
    			}

    			if (header_check == 12)
    			{

    				SCB->AIRCR = (0x5FA<<SCB_AIRCR_VECTKEY_Pos)|SCB_AIRCR_SYSRESETREQ_Msk;
    				header_check = 0;


    			}

    }
    UART_ClearStatusFlags(UART0, UART_GetStatusFlags(UART0));

}

void PGA_gpio_init(void){
	/* Initialise PGA0 and PGA1 and set them as unit gain (G = -1)*/
	gpio_pin_config_t pga_pin_config = {kGPIO_DigitalOutput, 0, };

	GPIO_PinInit(BOARD_PGA0_2_GPIO, BOARD_PGA0_2_GPIO_PIN, &pga_pin_config);
	GPIO_PinInit(BOARD_PGA0_1_GPIO, BOARD_PGA0_1_GPIO_PIN, &pga_pin_config);
	GPIO_PinInit(BOARD_PGA0_0_GPIO, BOARD_PGA0_0_GPIO_PIN, &pga_pin_config);


	GPIO_PinInit(BOARD_PGA1_2_GPIO, BOARD_PGA1_2_GPIO_PIN, &pga_pin_config);
	GPIO_PinInit(BOARD_PGA1_1_GPIO, BOARD_PGA1_1_GPIO_PIN, &pga_pin_config);
	GPIO_PinInit(BOARD_PGA1_0_GPIO, BOARD_PGA1_0_GPIO_PIN, &pga_pin_config);

}


void PGA0_unitGain(void){
	/* set the gain of PGA0 to be 1*/
	GPIO_WritePinOutput(BOARD_PGA0_2_GPIO, BOARD_PGA0_2_GPIO_PIN,0);
	GPIO_WritePinOutput(BOARD_PGA0_1_GPIO, BOARD_PGA0_1_GPIO_PIN,0);
	GPIO_WritePinOutput(BOARD_PGA0_0_GPIO, BOARD_PGA0_0_GPIO_PIN,1);
	PGA0_gain=1;

}

void PGA1_unitGain(void){
	/* set the gain of PGA1 to be 1*/
	GPIO_WritePinOutput(BOARD_PGA1_2_GPIO, BOARD_PGA1_2_GPIO_PIN,0);
	GPIO_WritePinOutput(BOARD_PGA1_1_GPIO, BOARD_PGA1_1_GPIO_PIN,0);
	GPIO_WritePinOutput(BOARD_PGA1_0_GPIO, BOARD_PGA1_0_GPIO_PIN,1);
	PGA1_gain=1;
}

void PGA0_02xGain(void){
	/* set the gain of PGA0 to be 2*/
	GPIO_WritePinOutput(BOARD_PGA0_2_GPIO, BOARD_PGA0_2_GPIO_PIN,0);
	GPIO_WritePinOutput(BOARD_PGA0_1_GPIO, BOARD_PGA0_1_GPIO_PIN,1);
	GPIO_WritePinOutput(BOARD_PGA0_0_GPIO, BOARD_PGA0_0_GPIO_PIN,0);
	PGA0_gain=2;
}

void PGA1_02xGain(void){
	/* set the gain of PGA1 to be 2*/
	GPIO_WritePinOutput(BOARD_PGA1_2_GPIO, BOARD_PGA1_2_GPIO_PIN,0);
	GPIO_WritePinOutput(BOARD_PGA1_1_GPIO, BOARD_PGA1_1_GPIO_PIN,1);
	GPIO_WritePinOutput(BOARD_PGA1_0_GPIO, BOARD_PGA1_0_GPIO_PIN,0);
	PGA1_gain=2;
}

void PGA0_05xGain(void){
	/* set the gain of PGA0 to be 2*/
	GPIO_WritePinOutput(BOARD_PGA0_2_GPIO, BOARD_PGA0_2_GPIO_PIN,0);
	GPIO_WritePinOutput(BOARD_PGA0_1_GPIO, BOARD_PGA0_1_GPIO_PIN,1);
	GPIO_WritePinOutput(BOARD_PGA0_0_GPIO, BOARD_PGA0_0_GPIO_PIN,1);
	PGA0_gain=5;
}

void PGA1_05xGain(void){
	/* set the gain of PGA1 to be 2*/
	GPIO_WritePinOutput(BOARD_PGA1_2_GPIO, BOARD_PGA1_2_GPIO_PIN,0);
	GPIO_WritePinOutput(BOARD_PGA1_1_GPIO, BOARD_PGA1_1_GPIO_PIN,1);
	GPIO_WritePinOutput(BOARD_PGA1_0_GPIO, BOARD_PGA1_0_GPIO_PIN,1);
	PGA1_gain=5;
}

void PGA0_10xGain(void){
	/* set the gain of PGA0 to be 10*/
	GPIO_WritePinOutput(BOARD_PGA0_2_GPIO, BOARD_PGA0_2_GPIO_PIN,1);
	GPIO_WritePinOutput(BOARD_PGA0_1_GPIO, BOARD_PGA0_1_GPIO_PIN,0);
	GPIO_WritePinOutput(BOARD_PGA0_0_GPIO, BOARD_PGA0_0_GPIO_PIN,0);
	PGA0_gain=10;
}

void PGA1_10xGain(void){
	/* set the gain of PGA1 to be 10*/
	GPIO_WritePinOutput(BOARD_PGA1_2_GPIO, BOARD_PGA1_2_GPIO_PIN,1);
	GPIO_WritePinOutput(BOARD_PGA1_1_GPIO, BOARD_PGA1_1_GPIO_PIN,0);
	GPIO_WritePinOutput(BOARD_PGA1_0_GPIO, BOARD_PGA1_0_GPIO_PIN,0);
	PGA1_gain=10;
}

void PGA0_20xGain(void){
	/* set the gain of PGA0 to be 20*/
	GPIO_WritePinOutput(BOARD_PGA0_2_GPIO, BOARD_PGA0_2_GPIO_PIN,1);
	GPIO_WritePinOutput(BOARD_PGA0_1_GPIO, BOARD_PGA0_1_GPIO_PIN,0);
	GPIO_WritePinOutput(BOARD_PGA0_0_GPIO, BOARD_PGA0_0_GPIO_PIN,1);
	PGA0_gain=20;
}

void PGA1_20xGain(void){
	/* set the gain of PGA1 to be 20*/
	GPIO_WritePinOutput(BOARD_PGA1_2_GPIO, BOARD_PGA1_2_GPIO_PIN,1);
	GPIO_WritePinOutput(BOARD_PGA1_1_GPIO, BOARD_PGA1_1_GPIO_PIN,0);
	GPIO_WritePinOutput(BOARD_PGA1_0_GPIO, BOARD_PGA1_0_GPIO_PIN,1);
	PGA1_gain=20;
}

void PGA0_50xGain(void){
	/* set the gain of PGA0 to be 50*/
	GPIO_WritePinOutput(BOARD_PGA0_2_GPIO, BOARD_PGA0_2_GPIO_PIN,1);
	GPIO_WritePinOutput(BOARD_PGA0_1_GPIO, BOARD_PGA0_1_GPIO_PIN,1);
	GPIO_WritePinOutput(BOARD_PGA0_0_GPIO, BOARD_PGA0_0_GPIO_PIN,0);
	PGA0_gain=50;
}

void PGA1_50xGain(void){
	/* set the gain of PGA1 to be 50*/
	GPIO_WritePinOutput(BOARD_PGA1_2_GPIO, BOARD_PGA1_2_GPIO_PIN,1);
	GPIO_WritePinOutput(BOARD_PGA1_1_GPIO, BOARD_PGA1_1_GPIO_PIN,1);
	GPIO_WritePinOutput(BOARD_PGA1_0_GPIO, BOARD_PGA1_0_GPIO_PIN,0);
	PGA1_gain=50;
}

void PGA0_100xGain(void){
	/* set the gain of PGA0 to be 100*/
	GPIO_WritePinOutput(BOARD_PGA0_2_GPIO, BOARD_PGA0_2_GPIO_PIN,1);
	GPIO_WritePinOutput(BOARD_PGA0_1_GPIO, BOARD_PGA0_1_GPIO_PIN,1);
	GPIO_WritePinOutput(BOARD_PGA0_0_GPIO, BOARD_PGA0_0_GPIO_PIN,1);
	PGA0_gain=100;
}

void PGA1_100xGain(void){
	/* set the gain of PGA1 to be 100*/
	GPIO_WritePinOutput(BOARD_PGA1_2_GPIO, BOARD_PGA1_2_GPIO_PIN,1);
	GPIO_WritePinOutput(BOARD_PGA1_1_GPIO, BOARD_PGA1_1_GPIO_PIN,1);
	GPIO_WritePinOutput(BOARD_PGA1_0_GPIO, BOARD_PGA1_0_GPIO_PIN,1);
	PGA1_gain=100;
}





void initMarker()
{
	/* Define the init structure for the analogue MUX */
	gpio_pin_config_t mux_config = {kGPIO_DigitalOutput, 0,	};
	/* Init output GPIO for analogue MUX. */
	GPIO_PinInit(BOARD_A0_GPIO, BOARD_A0_GPIO_PIN, &mux_config); // MarkerPulse : one pulse every period of sample window
	GPIO_PinInit(BOARD_A1_GPIO, BOARD_A1_GPIO_PIN, &mux_config); // Trigger : On when Measuring
}

void startMeasureMarker()
{
	GPIO_WritePinOutput(BOARD_A1_GPIO, BOARD_A1_GPIO_PIN, 1);
}

void stopMeasureMarker()
{
	GPIO_WritePinOutput(BOARD_A1_GPIO, BOARD_A1_GPIO_PIN, 0);
}

void togglePITMarker()
{
	GPIO_TogglePinsOutput(BOARD_A0_GPIO, 1U << BOARD_A0_GPIO_PIN);
}


void copyToSendingBuffer()
{
	memcpy (result_buffer, buffer, sizeof(buffer[0])*ADC_SAMPLE_SIZE );
	memcpy (result_buffer_A1, buffer_A1, sizeof(buffer_A1[0])*ADC_SAMPLE_SIZE );
//	memset(globalSignalArray,0,signalSize*sizeof(uint16_t));
}



void DAC_ADC_init()
{
	/* ----------------------------Configure the DAC--------------------------- */
    dac_config_t dacConfigStruct;
	DAC_GetDefaultConfig(&dacConfigStruct);
	dacConfigStruct.referenceVoltageSource = kDAC_ReferenceVoltageSourceVref2;
	dacConfigStruct.enableLowPowerMode = false;
	DAC_Init(DAC0, &dacConfigStruct);
	DAC_Enable(DAC0, true);
	dac_buffer_config_t dacBufferConfigStruct;
	DAC_GetDefaultBufferConfig(&dacBufferConfigStruct);
	dacBufferConfigStruct.triggerMode = kDAC_BufferTriggerBySoftwareMode;
	DAC_EnableBufferDMA(DAC0, true);
	DAC_SetBufferConfig(DAC0, &dacBufferConfigStruct);

	//DAC_SetBufferValue(DAC0, 0U, 0x7FF); // Succeeds: quick test to output 3.3v/2

	/* ----------------------------Configure the ADC--------------------------- */
	adc16_config_t adc16ConfigStruct;
	ADC16_GetDefaultConfig(&adc16ConfigStruct);
#if defined(BOARD_ADC_USE_ALT_VREF)
    adc16ConfigStruct.referenceVoltageSource = kADC16_ReferenceVoltageSourceValt;
#endif
    adc16ConfigStruct.resolution = kADC16_ResolutionSE16Bit;
    adc16ConfigStruct.clockDivider = kADC16_ClockDivider1;  // divided by 4 >> get 1MHz clock for ADC
    adc16ConfigStruct.clockSource = kADC16_ClockSourceAlt2; // PCC or clk_out = 4 M Hz
    //adc16ConfigStruct.enableDifferentialConversion = true;
    adc16ConfigStruct.enableHighSpeed = true;

    ADC16_Init(ADC16_BASEADDR, &adc16ConfigStruct);
    ADC16_EnableHardwareTrigger(ADC16_BASEADDR, false);
    ADC16_EnableDMA(ADC16_BASEADDR, true);
#if defined(FSL_FEATURE_ADC16_HAS_CALIBRATION) && FSL_FEATURE_ADC16_HAS_CALIBRATION
	if (kStatus_Success == ADC16_DoAutoCalibration(ADC16_BASEADDR))	{
		//PRINTF("\r\nADC16_DoAutoCalibration() Done.");
	} else {
		PRINTF("ADC16_DoAutoCalibration() Failed.\r\n");
		while(1){}
	}
#endif

	ADC16_Init(ADC16_BASEADDR_A1, &adc16ConfigStruct);
	    ADC16_EnableHardwareTrigger(ADC16_BASEADDR_A1, false);
	    ADC16_EnableDMA(ADC16_BASEADDR_A1, true);
	#if defined(FSL_FEATURE_ADC16_HAS_CALIBRATION) && FSL_FEATURE_ADC16_HAS_CALIBRATION
		if (kStatus_Success == ADC16_DoAutoCalibration(ADC16_BASEADDR_A1))	{
			//PRINTF("\r\nADC16_DoAutoCalibration() Done.");
		} else {
			PRINTF("ADC16_DoAutoCalibration() Failed.\r\n");
			while(1){}
		}
	#endif

	/* -----------------------------DMAMUX setup------------------------------- */
	// Use DMAMUX0 internal channel number 0 to connect PIT event to DMA channel 0 request
	DMAMUX_Init(DMAMUX0);
	DMAMUX_DisableChannel(DMAMUX0, 0/* DMAMUX channel number */); // Disable channel prior configuring it
	// But, default source 0 is "Disable" - set to "always on" source...
	DMAMUX_SetSource           (DMAMUX0, 0, (uint8_t)kDmaRequestMux0AlwaysOn63 /*48 PDB*/);
	DMAMUX_EnablePeriodTrigger (DMAMUX0, 0);
	DMAMUX_EnableChannel       (DMAMUX0, 0);

	DMAMUX_SetSource           (DMAMUX0, 1, (uint8_t)kDmaRequestMux0ADC0);
	//DMAMUX_SetSource           (DMAMUX0, 1, (uint8_t)kDmaRequestMux0AlwaysOn62);
	DMAMUX_DisablePeriodTrigger(DMAMUX0, 1);
	DMAMUX_EnableChannel       (DMAMUX0, 1);

	DMAMUX_SetSource           (DMAMUX0, 2, (uint8_t)kDmaRequestMux0ADC1);
	//DMAMUX_SetSource           (DMAMUX0, 1, (uint8_t)kDmaRequestMux0AlwaysOn62);
	DMAMUX_DisablePeriodTrigger(DMAMUX0, 2);
	DMAMUX_EnableChannel       (DMAMUX0, 2);

	// Set up DMA channel 0 to read from data buffer and write to DAC
	//DMA_Type* pDMA0 = DMA0; // expose for debugger, since "Peripherals" viewer doesn't work in Kinetis Studio
	/* -------------EDMA setup------------- */
	edma_config_t edmaConfig;
	EDMA_GetDefaultConfig(&edmaConfig);
	EDMA_Init(DMA0,&edmaConfig);

	/* -----------------------------DAC DMA register setup--------------------------------- */
	DMA0->CR = 0; // default mode of operation for DMA (no minor loop mapping, etc)
	DMA0->TCD[0].SADDR = (uint32_t)(SOURCE_ADDRESS); // source address
	DMA0->TCD[0].DADDR = (uint32_t)(&DAC0->DAT);  // destination address
	// Source data and destination data transfer size
	DMA0->TCD[0].ATTR = DMA_ATTR_SSIZE(kEDMA_TransferSize2Bytes) | DMA_ATTR_DSIZE(kEDMA_TransferSize2Bytes);
	assert(DMA0->TCD[0].ATTR==0x0101);
	DMA0->TCD[0].SOFF = 2; // increment source address by 2 after each 2-byte transfer
	DMA0->TCD[0].DOFF = 0; // destination address is fixed DAC; do not increment
	DMA0->TCD[0].NBYTES_MLNO = 2; // 2 bytes to DAC per transfer
	DMA0->TCD[0].SLAST = -SOURCE_CNT*2; // decrement SADDR back to source start address after completing a major loop
	DMA0->TCD[0].DLAST_SGA = 0; // destination address (DAC) is not adjusted after completing a major loop
	DMA0->TCD[0].BITER_ELINKNO = SOURCE_CNT;
	DMA0->TCD[0].CITER_ELINKNO = SOURCE_CNT; // transfers per major loop
	DMA0->SERQ = DMA_SERQ_SERQ(0); // enable DMA channel 0

	/* -----------------------------ADC DMA register setup--------------------------------- */
	DMA0->TCD[1].SADDR = (uint32_t)(&ADC0->R[ADC16_CHANNEL_GROUP]); // source address
	DMA0->TCD[1].DADDR = (uint32_t)(&buffer[0]);  // destination address
	// Source data and destination data transfer size
	DMA0->TCD[1].ATTR = DMA_ATTR_SSIZE(kEDMA_TransferSize2Bytes) | DMA_ATTR_DSIZE(kEDMA_TransferSize2Bytes);
	//assert(DMA0->TCD[1].ATTR==0x0101);
	DMA0->TCD[1].SOFF = 0; // destination address is fixed ADC; do not increment
	DMA0->TCD[1].DOFF = 2; // increment source address by 2 after each 2-byte transfer
	DMA0->TCD[1].NBYTES_MLNO = 2; // 2 bytes to DAC per transfer
	DMA0->TCD[1].SLAST = 0; // destination address (ADC) is not adjusted after completing a major loop
	DMA0->TCD[1].DLAST_SGA = -ADC_SAMPLE_SIZE*2; // decrement DADDR back to source start address after completing a major loop
	DMA0->TCD[1].BITER_ELINKNO = ADC_SAMPLE_SIZE;
	DMA0->TCD[1].CITER_ELINKNO = ADC_SAMPLE_SIZE; // transfers per major loop
	DMA0->SERQ = DMA_SERQ_SERQ(1); // enable DMA channel 1

	/* -----------------------------ADC DMA register setup--------------------------------- */
	DMA0->TCD[2].SADDR = (uint32_t)(&ADC1->R[ADC16_CHANNEL_GROUP]); // source address
	DMA0->TCD[2].DADDR = (uint32_t)(&buffer_A1[0]);  // destination address
	// Source data and destination data transfer size
	DMA0->TCD[2].ATTR = DMA_ATTR_SSIZE(kEDMA_TransferSize2Bytes) | DMA_ATTR_DSIZE(kEDMA_TransferSize2Bytes);
	//assert(DMA0->TCD[1].ATTR==0x0101);
	DMA0->TCD[2].SOFF = 0; // destination address is fixed ADC; do not increment
	DMA0->TCD[2].DOFF = 2; // increment source address by 2 after each 2-byte transfer
	DMA0->TCD[2].NBYTES_MLNO = 2; // 2 bytes to DAC per transfer
	DMA0->TCD[2].SLAST = 0; // destination address (ADC) is not adjusted after completing a major loop
	DMA0->TCD[2].DLAST_SGA = -ADC_SAMPLE_SIZE*2; // decrement DADDR back to source start address after completing a major loop
	DMA0->TCD[2].BITER_ELINKNO = ADC_SAMPLE_SIZE;
	DMA0->TCD[2].CITER_ELINKNO = ADC_SAMPLE_SIZE; // transfers per major loop
	DMA0->SERQ = DMA_SERQ_SERQ(2); // enable DMA channel 2


	/* -------------------------------DAC PIT setup------------------------------- */
	pit_config_t pit_setup;
	PIT_GetDefaultConfig(&pit_setup);
	pit_setup.enableRunInDebug = 0;
	PIT_Init(PIT,&pit_setup);
	PIT_EnableInterrupts(PIT, kPIT_Chnl_1, kPIT_TimerInterruptEnable);
	EnableIRQ(PIT_IRQ_ID);


    //PIT_SetTimerPeriod(PIT, PIT_CHANNEL, (PIT_SOURCE_CLOCK / (TARGET_FREQUENCY_HZ*SOURCE_CNT)) );
	PIT_SetTimerPeriod(PIT, kPIT_Chnl_0, (PIT_SOURCE_CLOCK / DAC_SAMPLE_FREQ) );
    PIT_SetTimerPeriod(PIT, kPIT_Chnl_1, (PIT_SOURCE_CLOCK / ADC_SAMPLE_FREQ) );
    PIT_SetTimerPeriod(PIT, kPIT_Chnl_2, (PIT_SOURCE_CLOCK / ADC_SAMPLE_FREQ) );

	PIT_StartTimer(PIT, kPIT_Chnl_0); // PIT for DAC (No interrupt)
    PIT_StartTimer(PIT, kPIT_Chnl_1); // PIT for ADC (Interrupt to PIT_HANDLER())
    PIT_StartTimer(PIT, kPIT_Chnl_2); // PIT for ADC (Interrupt to PIT_HANDLER())
    /* Enter an infinite loop */
}



void uart_send_bytes(uint8_t *p, uint16_t size)
{
	for(uint16_t i = 0; i < size; i++){
		PRINTF("%c", p[i]);
	}
}


void led_init()
{
	gpio_pin_config_t led_config = {kGPIO_DigitalOutput, 0,	};
	GPIO_PinInit(BOARD_INITPINS_LED_BLUE_GPIO, BOARD_INITPINS_LED_BLUE_PIN, &led_config);
	GPIO_PinInit(BOARD_INITPINS_LED_RED_GPIO, BOARD_INITPINS_LED_RED_PIN, &led_config);
	GPIO_PinInit(BOARD_INITPINS_LED_GREEN_GPIO, BOARD_INITPINS_LED_GREEN_PIN, &led_config);
}


void led_white_off()
{
	GPIO_WritePinOutput(BOARD_INITPINS_LED_BLUE_GPIO, BOARD_INITPINS_LED_BLUE_PIN,1);
	GPIO_WritePinOutput(BOARD_INITPINS_LED_RED_GPIO, BOARD_INITPINS_LED_RED_PIN,1);
	GPIO_WritePinOutput(BOARD_INITPINS_LED_GREEN_GPIO, BOARD_INITPINS_LED_GREEN_PIN,1);
}

void led_white_on()
{
	GPIO_WritePinOutput(BOARD_INITPINS_LED_BLUE_GPIO, BOARD_INITPINS_LED_BLUE_PIN,0);
	GPIO_WritePinOutput(BOARD_INITPINS_LED_RED_GPIO, BOARD_INITPINS_LED_RED_PIN,0);
	GPIO_WritePinOutput(BOARD_INITPINS_LED_GREEN_GPIO, BOARD_INITPINS_LED_GREEN_PIN,0);
}

void led_blue_on()
{
	GPIO_WritePinOutput(BOARD_INITPINS_LED_BLUE_GPIO, BOARD_INITPINS_LED_BLUE_PIN,0);
	GPIO_WritePinOutput(BOARD_INITPINS_LED_RED_GPIO, BOARD_INITPINS_LED_RED_PIN,1);
	GPIO_WritePinOutput(BOARD_INITPINS_LED_GREEN_GPIO, BOARD_INITPINS_LED_GREEN_PIN,1);
}

void led_red_on()
{
	GPIO_WritePinOutput(BOARD_INITPINS_LED_BLUE_GPIO, BOARD_INITPINS_LED_BLUE_PIN,1);
	GPIO_WritePinOutput(BOARD_INITPINS_LED_RED_GPIO, BOARD_INITPINS_LED_RED_PIN,0);
	GPIO_WritePinOutput(BOARD_INITPINS_LED_GREEN_GPIO, BOARD_INITPINS_LED_GREEN_PIN,1);
}


void send_result()
{
	static uint16_t header_trial_number = 0;

	header_trial_number = header_trial_number + 1;

    uart_send_bytes((uint8_t*)&header_trial_number, sizeof(header_trial_number));
    uart_send_bytes((uint8_t*)&header_adc_sample, sizeof(header_adc_sample));
    uart_send_bytes((uint8_t*)&header_pattern_code, sizeof(header_pattern_code));
    uart_send_bytes((uint8_t*)&PGA0_gain, sizeof(PGA0_gain));
    uart_send_bytes((uint8_t*)&PGA1_gain, sizeof(PGA1_gain));
    uart_send_bytes((uint8_t*)&header_sample_number, sizeof(header_sample_number));
    uart_send_bytes((uint8_t*)&result_buffer[0], sizeof(result_buffer));
    uart_send_bytes((uint8_t*)&header_sample_number, sizeof(header_sample_number));
    uart_send_bytes((uint8_t*)&result_buffer_A1[0], sizeof(result_buffer_A1));

}


void BOTTON_MEASURE_init(void)
{
	/* Init input switch GPIO for A1. */
//    gpio_pin_config_t sw_config = {kGPIO_DigitalInput, 0, };
	PORT_SetPinInterruptConfig(BOTTON_MEASURE_PORT, BOTTON_MEASURE_GPIO_PIN, kPORT_InterruptFallingEdge);

    gpio_pin_config_t pin_config = {kGPIO_DigitalInput, 0, };
	PORT_SetPinInterruptConfig(CONTROL_MEASURE_PORT, CONTROL_MEASURE_GPIO_PIN, kPORT_InterruptFallingEdge);


//	GPIO_PinInit(BOTTON_MEASURE_GPIO, BOTTON_MEASURE_GPIO_PIN, &sw_config);
	GPIO_PinInit(CONTROL_MEASURE_GPIO, CONTROL_MEASURE_GPIO_PIN, &pin_config);
	EnableIRQ(BOTTON_MEASURE_IRQ);

}


/* IRQ interupt action when switch is pressed */
void BOTTON_MEASURE_IRQ_HANDLER(void)
{
	/* A1. */
    /* Clear external interrupt flag. */
    GPIO_ClearPinsInterruptFlags(BOTTON_MEASURE_GPIO, 1U << BOTTON_MEASURE_GPIO_PIN);
    GPIO_ClearPinsInterruptFlags(CONTROL_MEASURE_GPIO, 1U << CONTROL_MEASURE_GPIO_PIN);

    flagMeasureRequested = true;

}



void fillSignalArray(float32_t *pSignalArray, int length, float32_t value)
{
    for (int i = 0; i < length; i++) {
        pSignalArray[i] = value;
    }
}


void addSineWave(float32_t *pSignalArray, int length, float32_t frequency, float32_t amplitude)
{
    for (int i = 0; i < length; i++) {
        pSignalArray[i] += -1*arm_cos_f32(2*PI*frequency*((float32_t)i/(float32_t)length))*amplitude;
    }
}


void getNormalizedSignalArray(float32_t *pSourceSignalArray, uint16_t *pNormSignalArray, int length, uint16_t lowerLimit, uint16_t upperLimit)
{
    // Find Range of Source Signal
    float32_t smin, smax, srange, sscale;
    smin = pSourceSignalArray[0];
    smax = pSourceSignalArray[0];

    for (int i = 1; i < length; i++) {
        if (pSourceSignalArray[i] < smin) {
            smin = pSourceSignalArray[i];
        }
        if (pSourceSignalArray[i] > smax) {
            smax = pSourceSignalArray[i];
        }
    }
    srange = smax - smin;
    sscale = upperLimit - lowerLimit;

    // Apply Full-Range Normalization : from smin-to-smax to lowerLimit-to-upperLimit
    for (int i = 0; i < length; i++) {
        pNormSignalArray[i] =  (uint16_t) (((pSourceSignalArray[i] - smin) * sscale) / srange) + lowerLimit;

        /* -- Note : Actually, Equation shoud be  " (((pSource-smin) / srange) * sscale) + lowerLimit " .
                     However, for preserving the decimal & reduce float's flooring error, Eq. has been adapted as shown.

        */
    }
}



void generateSignalArray(float32_t target_frequency)
{
    float32_t localSignalArray[SIGNAL_ARRAY_SIZE];

    float32_t frequency_scaling = DAC_SAMPLE_FREQ / SIGNAL_ARRAY_SIZE;
    target_frequency = target_frequency / frequency_scaling;

    // Clear all value in localSignalArray.
    fillSignalArray(localSignalArray, SIGNAL_ARRAY_SIZE, 0); // Fill all member with 0

    // Add 1st SineWave into localSignalArray
    addSineWave(localSignalArray, SIGNAL_ARRAY_SIZE, target_frequency, 1.0);

    // Normalizing it into specific range, cast into uint16_t, and copy to target array.
    getNormalizedSignalArray(localSignalArray, globalSignalArray, SIGNAL_ARRAY_SIZE, SIGNAL_LOWER_LIMIT, SIGNAL_UPPER_LIMIT);

}

